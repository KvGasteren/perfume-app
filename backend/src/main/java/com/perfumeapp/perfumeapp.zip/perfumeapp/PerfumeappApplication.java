package com.perfumeapp.perfumeapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PerfumeappApplication {

	public static void main(String[] args) {
		SpringApplication.run(PerfumeappApplication.class, args);
	}

}
