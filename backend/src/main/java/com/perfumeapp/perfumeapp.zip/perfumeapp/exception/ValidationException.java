package com.perfumeapp.perfumeapp.exception;

public class ValidationException {
}
