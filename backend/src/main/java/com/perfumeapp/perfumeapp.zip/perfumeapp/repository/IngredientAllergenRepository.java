package com.perfumeapp.perfumeapp.repository;

import com.perfumeapp.perfumeapp.model.IngredientAllergen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IngredientAllergenRepository extends JpaRepository<IngredientAllergen, Long> {
}
